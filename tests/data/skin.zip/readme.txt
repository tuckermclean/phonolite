made by tools/fixtures.py
